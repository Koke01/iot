package com.example.powertrack.model;

public class Sensor {
    private String nombre;
    private String modelo;
    private float lecturaActual;
    private Aparato aparato;
    private Ubicacion ubicacion;
    private String tipo; // "Temperatura" o "Humedad"
    private String descripcion;

    public Sensor(String nombre, String modelo, float lecturaActual, Aparato aparato, Ubicacion ubicacion, String tipo, String descripcion) {
        this.nombre = nombre;
        this.modelo = modelo;
        this.lecturaActual = lecturaActual;
        this.aparato = aparato;
        this.ubicacion = ubicacion;
        this.tipo = tipo;
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public float getLecturaActual() {
        return lecturaActual;
    }

    public void setLecturaActual(float lecturaActual) {
        this.lecturaActual = lecturaActual;
    }

    public Aparato getAparato() {
        return aparato;
    }

    public void setAparato(Aparato aparato) {
        this.aparato = aparato;
    }

    public Ubicacion getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(Ubicacion ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + "\n" +
                "Modelo: " + modelo + "\n" +
                "Lectura Actual: " + lecturaActual + "\n" +
                "Tipo: " + tipo + "\n" +
                "Descripción: " + (descripcion != null ? descripcion : "No asignada") + "\n" +
                "Ubicación: " + (ubicacion != null ? ubicacion.toString() : "No asignada") + "\n" +
                "Aparato: " + (aparato != null ? aparato.toString() : "No asignado");
    }
}
