package com.example.powertrack.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.powertrack.R;
import com.example.powertrack.model.Sensor;

import java.util.List;

public class SensoresAdapter extends RecyclerView.Adapter<SensoresAdapter.ViewHolder> {

    private List<Sensor> sensores;

    public SensoresAdapter(List<Sensor> sensores) {
        this.sensores = sensores;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_view_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Sensor sensor = sensores.get(position);

        holder.textViewNombre.setText("Nombre: " + sensor.getNombre());
        holder.textViewModelo.setText("Modelo: " + sensor.getModelo());
        holder.textViewDescripcion.setText("Descripción: " + (sensor.getDescripcion() != null ? sensor.getDescripcion() : "N/A"));
        holder.textViewLecturaActual.setText("Lectura Actual: " + sensor.getLecturaActual());

        if (sensor.getAparato() != null) {
            holder.textViewAparato.setText("Aparato: " + sensor.getAparato().getNombre());
        } else {
            holder.textViewAparato.setText("Aparato: No asignado");
        }

        if (sensor.getUbicacion() != null) {
            holder.textViewUbicacion.setText("Ubicación: " + sensor.getUbicacion().getNombre());
        } else {
            holder.textViewUbicacion.setText("Ubicación: No asignada");
        }

        holder.textViewTipo.setText("Tipo: " + sensor.getTipo());
    }

    @Override
    public int getItemCount() {
        return sensores.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView textViewNombre;
        private TextView textViewModelo;
        private TextView textViewDescripcion;
        private TextView textViewLecturaActual;
        private TextView textViewAparato;
        private TextView textViewUbicacion;
        private TextView textViewTipo;

        public ViewHolder(View view) {
            super(view);
            textViewNombre = view.findViewById(R.id.textViewNombre);
            textViewModelo = view.findViewById(R.id.textViewModelo);
            textViewDescripcion = view.findViewById(R.id.textViewDescripcion);
            textViewLecturaActual = view.findViewById(R.id.textViewLecturaActual);
            textViewAparato = view.findViewById(R.id.textViewAparato);
            textViewUbicacion = view.findViewById(R.id.textViewUbicacion);
            textViewTipo = view.findViewById(R.id.textViewTipo);
        }
    }
}
