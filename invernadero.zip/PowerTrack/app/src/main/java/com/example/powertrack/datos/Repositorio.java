package com.example.powertrack.datos;

import com.example.powertrack.model.Sensor;
import com.example.powertrack.model.Ubicacion;
import com.example.powertrack.model.TipoAparato;

import java.util.ArrayList;
import java.util.List;

public class Repositorio {

    private static Repositorio instance = null;
    public List<TipoAparato> tipos;

    public List<Sensor> sensores;
    public List<Ubicacion> ubicaciones;

    protected Repositorio() {
        sensores = new ArrayList<>();
        ubicaciones = new ArrayList<>();
        tipos = new ArrayList<>();

        // Agregar tipos de ejemplo
        tipos.add(new TipoAparato("Temperatura", "Mide la temperatura"));
        tipos.add(new TipoAparato("Humedad", "Mide la humedad"));

        // Agregar ubicaciones de ejemplo
        ubicaciones.add(new Ubicacion("Invernadero 1", "Sección A"));
        ubicaciones.add(new Ubicacion("Invernadero 2", "Sección B"));
        ubicaciones.add(new Ubicacion("Invernadero 3", "Sección C"));

        // Agregar sensores de ejemplo con descripción
        sensores.add(new Sensor("Sensor 1", "Modelo A", 22.5f, null, ubicaciones.get(0), "Temperatura", "Sensor de temperatura en invernadero 1"));
        sensores.add(new Sensor("Sensor 2", "Modelo B", 18.0f, null, ubicaciones.get(1), "Humedad", "Sensor de humedad en invernadero 2"));
    }

    public static synchronized Repositorio getInstance() {
        if (instance == null) {
            instance = new Repositorio();
        }
        return instance;
    }
}
