package com.example.powertrack;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Asociar el Activity con su Layout
        setContentView(R.layout.activity_main);

        // Asociar el recurso de Layout (botón) con la variable solo para Sensores
        Button sensoresButton = findViewById(R.id.sensoresButton);

        // Asociar el evento OnClick solo para el botón de Sensores
        sensoresButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Iniciar SensoresActivity
                Intent intent = new Intent(MainActivity.this, SensoresActivity.class);
                startActivity(intent);
            }
        });
    }

    public void saludar(View view) {
        // Declaración de una variable entera para la duración del Toast
        int duracion = Toast.LENGTH_LONG;
        // Declaración de una variable de tipo secuencia de caracteres (String)
        CharSequence mensaje = "Hola mundo!";
        // Creación y lanzamiento de un aviso emergente
        Toast toast = Toast.makeText(this, mensaje, duracion);
        toast.show();
    }
}
